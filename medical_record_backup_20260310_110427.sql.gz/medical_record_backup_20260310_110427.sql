-- MySQL dump 10.13  Distrib 8.0.45, for Linux (aarch64)
--
-- Host: localhost    Database: medical_record
-- ------------------------------------------------------
-- Server version	8.0.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dictionary`
--

DROP TABLE IF EXISTS `dictionary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dictionary` (
  `id` varchar(32) NOT NULL,
  `error` varchar(100) NOT NULL COMMENT 'é”™è¯¯è¯',
  `correct` varchar(100) NOT NULL COMMENT 'æ­£ç¡®è¯',
  `category` varchar(20) DEFAULT NULL COMMENT 'ç±»åˆ«ï¼šdrugs/diseases/anatomy/exams/symptoms',
  `frequency` int DEFAULT '1' COMMENT 'å‘½ä¸­æ¬¡æ•°',
  `auto_apply` tinyint DEFAULT '1' COMMENT 'æ˜¯å¦è‡ªåŠ¨åº”ç”¨',
  `source` varchar(20) DEFAULT 'manual' COMMENT 'æ¥æºï¼šmanualæ‰‹åŠ¨/systemç³»ç»Ÿè‡ªåŠ¨',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_error` (`error`),
  KEY `idx_category` (`category`),
  KEY `idx_auto_apply` (`auto_apply`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='æ™ºèƒ½çº é”™è¯å…¸';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dictionary`
--

LOCK TABLES `dictionary` WRITE;
/*!40000 ALTER TABLE `dictionary` DISABLE KEYS */;
INSERT INTO `dictionary` VALUES ('d001','é˜¿èŽ«å¸æž—','é˜¿èŽ«è¥¿æž—','drugs',1,1,'manual','2026-03-04 20:16:28','2026-03-04 20:16:28'),('d002','å¤´è‹ž','å¤´å­¢','drugs',1,1,'manual','2026-03-04 20:16:28','2026-03-04 20:16:28'),('d003','æ­¥æ´›èŠ¬','å¸ƒæ´›èŠ¬','drugs',1,1,'manual','2026-03-04 20:16:28','2026-03-04 20:16:28'),('d004','å‘ç»•','å‘çƒ­','symptoms',1,1,'manual','2026-03-04 20:16:28','2026-03-04 20:16:28'),('d005','å’³é€Ÿ','å’³å—½','symptoms',1,1,'manual','2026-03-04 20:16:28','2026-03-04 20:16:28'),('d006','æ‰é€ƒä½“','æ‰æ¡ƒä½“','anatomy',1,1,'manual','2026-03-04 20:16:28','2026-03-04 20:16:28'),('d007','é›ªå¸¸è§„','è¡€å¸¸è§„','exams',1,1,'manual','2026-03-04 20:16:28','2026-03-04 20:16:28'),('d008','ä¸Šå‘¼é“æ„ŸæŸ“','ä¸Šå‘¼å¸é“æ„ŸæŸ“','diseases',1,1,'manual','2026-03-04 20:16:28','2026-03-04 20:16:28');
/*!40000 ALTER TABLE `dictionary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `metrics`
--

DROP TABLE IF EXISTS `metrics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `metrics` (
  `id` varchar(32) NOT NULL,
  `metric_type` varchar(50) NOT NULL COMMENT 'æŒ‡æ ‡ç±»åž‹ï¼šasr/generation/user',
  `metric_name` varchar(50) NOT NULL COMMENT 'æŒ‡æ ‡åç§°',
  `value` decimal(10,2) NOT NULL COMMENT 'æ•°å€¼',
  `stat_date` date NOT NULL COMMENT 'ç»Ÿè®¡æ—¥æœŸ',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_metric_date` (`metric_type`,`metric_name`,`stat_date`),
  KEY `idx_stat_date` (`stat_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='ç³»ç»Ÿç›‘æŽ§æŒ‡æ ‡';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metrics`
--

LOCK TABLES `metrics` WRITE;
/*!40000 ALTER TABLE `metrics` DISABLE KEYS */;
/*!40000 ALTER TABLE `metrics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `operation_logs`
--

DROP TABLE IF EXISTS `operation_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `operation_logs` (
  `id` varchar(32) NOT NULL,
  `user_id` varchar(32) NOT NULL,
  `action` varchar(50) NOT NULL COMMENT 'æ“ä½œç±»åž‹',
  `target_type` varchar(50) DEFAULT NULL COMMENT 'ç›®æ ‡ç±»åž‹ï¼špatient/visit/record',
  `target_id` varchar(32) DEFAULT NULL COMMENT 'ç›®æ ‡ID',
  `detail` json DEFAULT NULL COMMENT 'æ“ä½œè¯¦æƒ…',
  `ip_address` varchar(50) DEFAULT NULL COMMENT 'IPåœ°å€',
  `user_agent` varchar(500) DEFAULT NULL COMMENT 'UA',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_action` (`action`),
  KEY `idx_target` (`target_type`,`target_id`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='æ“ä½œæ—¥å¿—è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `operation_logs`
--

LOCK TABLES `operation_logs` WRITE;
/*!40000 ALTER TABLE `operation_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `operation_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patients`
--

DROP TABLE IF EXISTS `patients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `patients` (
  `id` varchar(32) NOT NULL COMMENT 'æ‚£è€…ID',
  `user_id` varchar(32) NOT NULL COMMENT 'æ‰€å±žç”¨æˆ·ID',
  `name` varchar(50) NOT NULL COMMENT 'å§“å',
  `card_no` varchar(50) DEFAULT NULL COMMENT 'å¡å·',
  `phone` varchar(20) DEFAULT NULL COMMENT 'æ‰‹æœºå·',
  `gender` tinyint DEFAULT NULL COMMENT 'æ€§åˆ«ï¼š0å¥³ 1ç”· 2å…¶ä»–',
  `birthday` date DEFAULT NULL COMMENT 'å‡ºç”Ÿæ—¥æœŸ',
  `id_card` varchar(18) DEFAULT NULL COMMENT 'èº«ä»½è¯å·',
  `address` varchar(255) DEFAULT NULL COMMENT 'åœ°å€',
  `allergy` text COMMENT 'è¿‡æ•å²',
  `deleted_at` datetime DEFAULT NULL COMMENT 'åˆ é™¤æ—¶é—´ï¼ˆè½¯åˆ é™¤ï¼‰',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_name` (`name`),
  KEY `idx_phone` (`phone`),
  KEY `idx_card_no` (`card_no`),
  KEY `idx_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='æ‚£è€…è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patients`
--

LOCK TABLES `patients` WRITE;
/*!40000 ALTER TABLE `patients` DISABLE KEYS */;
INSERT INTO `patients` VALUES ('p_227d2975889640ba','admin001','王五',NULL,'13600136000',1,NULL,NULL,NULL,NULL,NULL,'2026-03-05 11:55:26','2026-03-05 11:55:26'),('p_7b3650ca4eb5436b','u_61f732d5e9b14454','王妞妞',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-03-05 11:59:38','2026-03-05 11:59:38'),('p_927161b3972d4435','u_61f732d5e9b14454','妞妞王',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-03-05 19:40:52','2026-03-05 19:40:52');
/*!40000 ALTER TABLE `patients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `record_versions`
--

DROP TABLE IF EXISTS `record_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `record_versions` (
  `id` varchar(32) NOT NULL,
  `visit_id` varchar(32) NOT NULL COMMENT 'å°±è¯ŠID',
  `version` int NOT NULL COMMENT 'ç‰ˆæœ¬å·',
  `content` json NOT NULL COMMENT 'ç—…åŽ†å†…å®¹',
  `created_by` varchar(32) DEFAULT NULL COMMENT 'ä¿®æ”¹äººID',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_visit_id` (`visit_id`),
  KEY `idx_version` (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='ç—…åŽ†ç‰ˆæœ¬åŽ†å²';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `record_versions`
--

LOCK TABLES `record_versions` WRITE;
/*!40000 ALTER TABLE `record_versions` DISABLE KEYS */;
INSERT INTO `record_versions` VALUES ('rv_330f67bad89f4d6d','v_53649889ebdc4121',2,'{\"fields\": [{\"content\": \"\", \"field_key\": \"chief_complaint\"}, {\"content\": \"\", \"field_key\": \"present_illness\"}, {\"content\": \"\", \"field_key\": \"past_history\"}, {\"content\": \"\", \"field_key\": \"personal_history\"}, {\"content\": \"\", \"field_key\": \"family_history\"}, {\"content\": \"\", \"field_key\": \"physical_exam\"}, {\"content\": \"\", \"field_key\": \"auxiliary_exam\"}, {\"content\": \"\", \"field_key\": \"diagnosis\"}, {\"content\": \"\", \"field_key\": \"treatment\"}]}','u_61f732d5e9b14454','2026-03-07 12:01:15'),('rv_4cb0609eee1b4383','v_bb73c402325a4389',2,'{\"fields\": [{\"content\": \"\", \"field_key\": \"left\"}, {\"content\": \"\", \"field_key\": \"chief_complaint\"}, {\"content\": \"\", \"field_key\": \"present_illness\"}, {\"content\": \"\", \"field_key\": \"past_history\"}, {\"content\": \"\", \"field_key\": \"personal_history\"}, {\"content\": \"\", \"field_key\": \"family_history\"}, {\"content\": \"\", \"field_key\": \"physical_exam\"}, {\"content\": \"\", \"field_key\": \"auxiliary_exam\"}, {\"content\": \"\", \"field_key\": \"diagnosis\"}, {\"content\": \"\", \"field_key\": \"treatment\"}]}','u_61f732d5e9b14454','2026-03-09 16:34:51'),('rv_ce40147692f041de','v_a1b1cb3177ae4238',2,'{\"fields\": [{\"content\": \"\", \"field_key\": \"left\"}, {\"content\": \"\", \"field_key\": \"chief_complaint\"}, {\"content\": \"\", \"field_key\": \"present_illness\"}, {\"content\": \"\", \"field_key\": \"past_history\"}, {\"content\": \"\", \"field_key\": \"personal_history\"}, {\"content\": \"\", \"field_key\": \"family_history\"}, {\"content\": \"\", \"field_key\": \"physical_exam\"}, {\"content\": \"\", \"field_key\": \"auxiliary_exam\"}, {\"content\": \"\", \"field_key\": \"diagnosis\"}, {\"content\": \"\", \"field_key\": \"treatment\"}]}','u_61f732d5e9b14454','2026-03-09 16:22:50'),('rv_e48d550ac8e7471c','v_d275147bd62e42ca',2,'{\"fields\": [{\"content\": \"\", \"field_key\": \"left\"}, {\"content\": \"\", \"field_key\": \"chief_complaint\"}, {\"content\": \"\", \"field_key\": \"present_illness\"}, {\"content\": \"\", \"field_key\": \"past_history\"}, {\"content\": \"\", \"field_key\": \"personal_history\"}, {\"content\": \"\", \"field_key\": \"family_history\"}, {\"content\": \"\", \"field_key\": \"physical_exam\"}, {\"content\": \"\", \"field_key\": \"auxiliary_exam\"}, {\"content\": \"\", \"field_key\": \"diagnosis\"}, {\"content\": \"\", \"field_key\": \"treatment\"}]}','u_61f732d5e9b14454','2026-03-09 16:28:03');
/*!40000 ALTER TABLE `record_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recordings`
--

DROP TABLE IF EXISTS `recordings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recordings` (
  `id` varchar(32) NOT NULL,
  `visit_id` varchar(32) NOT NULL COMMENT 'å°±è¯ŠID',
  `filename` varchar(255) NOT NULL,
  `file_size` bigint DEFAULT NULL COMMENT 'æ–‡ä»¶å¤§å°ï¼ˆå­—èŠ‚ï¼‰',
  `duration` int DEFAULT NULL COMMENT 'æ—¶é•¿ï¼ˆç§’ï¼‰',
  `mime_type` varchar(50) DEFAULT NULL COMMENT 'æ–‡ä»¶ç±»åž‹',
  `audio_url` varchar(500) DEFAULT NULL COMMENT 'éŸ³é¢‘URLï¼ˆOSSè·¯å¾„ï¼‰',
  `transcription` longtext COMMENT 'è½¬å†™æ–‡æœ¬',
  `status` tinyint DEFAULT '0' COMMENT 'çŠ¶æ€ï¼š0å¾…è½¬å†™ 1è½¬å†™ä¸­ 2å·²å®Œæˆ 3å¤±è´¥',
  `task_id` varchar(64) DEFAULT NULL COMMENT 'è½¬å†™ä»»åŠ¡ID',
  `error_msg` varchar(500) DEFAULT NULL COMMENT 'é”™è¯¯ä¿¡æ¯',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `progress` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_visit_id` (`visit_id`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='å½•éŸ³è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recordings`
--

LOCK TABLES `recordings` WRITE;
/*!40000 ALTER TABLE `recordings` DISABLE KEYS */;
INSERT INTO `recordings` VALUES ('r_4646039df1694bd2','v_d275147bd62e42ca','肖成茜 2026年1月16日 视频2.MP3',66055573,0,'audio/mpeg','1773044872853-sgtw6dputf.MP3','你又是不看你企业 這樣會讓你覺得變好嗎 這樣這樣,這樣會覺得說不清楚 因為我今天不是很接 今天不是痛失這裏我覺得所的可能 有點這樣有點 不舒服,但是不是那種很痛 這樣其實是 你覺得我和你們好 我不知道很久沒覺得這個區域是不是跳鴨一個石頭的鴨頭不舒服 好,OK 我再一次上次的鴨頭 這個鴨頭 好,我們現在來看一下 我們來看一下 這是學生跟左燈體,讓人擺放開筆,使我剛剛還在不說一百分,而左燈不說一百分,只三右燈,還不照顧,或是說還有不說的。 但是左燈是我說的,對不對? 對,對,對,對,對,對,對,對,對,對。 因為左燈是學生,我剛剛以後走邊一村,放進去的表, 對,對,對,對,對。 好,好,好了,OK。 我以為我不貴貓 嗯 嗯 你覺得這個我很好吃嗎 嗯 嗯 怎樣 嗯 你要一點 軟嫩嫩嫩 真的真的軟嫩嫩我會吃嗎 嗯 嗯 嗯 嗯 嗯 嗯 嗯 嗯 嗯 嗯 嗯 嗯 嗯 嗯 嗯 嗯 在这件床早上是两个分 一部分是你的先达五上的一些纪录 你的法床直接问你其他PG的警察 就两个设计 你才会靠老鼓勢 那个靠老鼓勢可能贴任的贴任 贴任的贴任的贴任的贴任的贴任的贴任 这就是几肚 就是几个月有胸贵 一年纪了给立法打净胸 那可是一个人是一串的 航空 航空第二 航空第二 航空第二 航空第二 你这种航空有什么准处 你一串是几个月有信号的高 所以你信号是第一 用了大信号的信号 那就是你的一个的警察 你用的钱 所以你的那个你的警察 有什么几块 这个还要 他仰依之在这个位置上 在说在其他的理解上 如果还是这种 稍微回到这种设计的设计的设计的设计的时候 他们只在那股线上做成为了设计的 最后就是没有那么大的设计的 所以复拔到我刚才给你再课计的 在那种设计的时候 这种设计的设计应该是走实 那一种设计的设计 但是卖一种大走实的那种大走实的那种大走 而卖了很多很小 就说明你的新疆的意识 来到后期上的生活就是可能是个 是个经历的状态 那么你要跟你平时 最新体态的关注 好多方面有关 所以我后面的话 其实把它需要去规复你从这种设计的设计 对我们可能会带你去做一些教股 去生活对我的变形 这个是对你的教育教育的地方 方式带上 第一个基本是你的低纳肥 也跟你的胸肥胸肥是很久 因为正常人的胸肥胸肥胸肥胸肥胸肥胸肥胸 就像是一个延避 我们增加股跟那是参严久 它的这个延避上 它们这些应该有个 摩托力以后是它有个智商的 但你现在想在这个胸肥是 你只能温倒不敲的一个延避 那么你今天会在上面的不够不入 聪明的教 那这样的话 竟然股上的你只有 先等体肌上的形容机 它们会一直扯一个紧张照 把它拉着 把它叫 所以 它就可以 跟我刚才那种劇情的 其实是 到后面你的亲战股 叫我去帮你 交给你这样的办法 去训练了你的上的形容机 这样的办法是上的形容机 在我的亲战体肌上的防控 所以我我认为你先带上防控一样一样一样一样一样一样 所以样的办法是这样的股有一定会有鼓励 两个拿拉上去的做法 但是这个也是治疗 跟歌跟得上的本知 但与你的胸肥胸肥胸肤 我们需要百层的胸肥胸肥胸肥胸肥胸肥胸肥 这样的胸肥胸肥胸肥胸肥胸肥 它还许说 最后的胸肥胸肥胸肥胸肥的胸肥胸肥 所以其实 原理不成为原理 然后我看到那个时候 所以习惯肥胸肥胸肥胸肥胸肥 这就是这次 这边的股胸肥胸肥 因为你的胸肥胸肥胸肥胸肥胸肥胸肥胸肥的 狠胤肚子怕了肥胸肥胸肥胸肥胸肥把肥胸肥胸肥 Mi sob 对这就是其实重师的胸肥胸肥胸肥 所以因为我胸肥胸肥胸肥胸肥胸肥胸肥胸肥胸 CU 所以后面的话我们在康迫的宋教学校上的科学徒徒徒徒徒徒 我说过一些科学徒也好 你的这些问题可能也会能按照到这些 但是徒徒他们是一个礼物 他不是说礼物徒徒徒徒徒徒徒徒 你不免一次而然徒徒徒徒 三人有网治心理的生活 我那种 eresинки 你说我这些没有数人  aleg着你们 垃圾女 我这里有termicmon 我这里有更多数则 配上决quet 明明 明明 明仔真传 打算  grains叫 SCHĞ 你是三姐姐很想啊 你还想解决你右边的大部分 对呀 对呀 对呀 对呀 对呀 我确定能不能帮你 因为这个就已经多点在我们的 康子的腌界的这个地方 我怎么办 对我康子 可能组续这个位置 我觉得我们还是先几个前几块 要有一股 但有这个应该可以去呢 我看我们能帮我们的 这个面子多久 然后你让我们先拍照 我帮我们玩一下 然后你看到对比 我这种都是个 但一会儿啊 如果都处理我好像小小 天然的嘴里面 那我又会帮你干净的什么 我一半个月上的事 我看你的肩膀 对呀 对呀 对呀 对呀 对呀 对呀 对呀 对呀 对呀 对呀 对呀 对呀 对呀 对呀 对呀 对呀 对呀 对呀 对呀 对呀 对呀 对呀 对呀 对呀 对呀 对呀 对呀 对呀 对呀 对呀 对呀 就好,就好了。 就好,就好了。 就好。 就好,就好。 是不是覺得市場比較遠遠遠遠遠 你身邊會激進來 泡啊 你這是從會的地方 泡啊 有計劃的關係很整體 比如說他這個位置的時候 他會有些情緒 泡啊 泡車 有些人他會 八、二、一、二、一 情緒的市場會的感覺 因為劇情嘛 他一個情緒 他會出生一些小孩的情緒 情緒 情緒的話 我通過了 我通過了 我通過了 我通過了 我通過了 我通過了 你通過了 我通過了 我通過了 我通過了 我通過了 我通過了 我通過了 我通過了 你通過了 你每天都是 我都通過了 你還是想靠脫離你 我通過了 你感覺像什麼像嗎? 我可能就是那邊脫臉是那邊吧 就出資班了 出資班了 出資班了 那是我回家了 這樣已經帶上回家了 至於你一個右邊的水咬喊 叫我給我這是體驗的體驗 但是我現在看你的右邊的體驗 體驗上 接著我們可以看的體驗 這個體驗是三位的效果 因為體驗這個意外的體驗 它就骨血了 它就被從從尷尬你的體驗 但是你的最小的下層體驗 叫還要是2GD5D  indicates一位大幅 上班会,然后上班上班上班,上班上班上班下班下班 美国觉得方人其实不行,是不行的 然后本来我觉得都是一句 就是你看到一个美国的美国来不命 它的为什么美国表现是在那一边一个领的体屈 是因为领导时点小碰大堤,大堤地有一个小便宜的情况 但是到那边有千长河 今天我们就会直接 支开我们的面部一些感觉 感觉和提露 所以当情绪出现的时候 你的表情就是多自主出现 但是法治表情出现的时候 也会有情绪的这样 所以当你搞笑的时候 你的情绪也会很好 所以多也几个小声音 就有点情绪做关注 所以这个方向是故乡的吗? 所以我觉得 它的听党和那种天下视频 如果是要考驶的话 可以当日减天的一条声 可以给它做一天好的处理 但是除了好不用找你的声音 然后的话按开 我们的高音控制就OK了 高音控制 然后它去做一些 这个这个 它们 今天好 然后它去做一些声音 它们的情况就是做到一些声音 OK 然后也可以找一套片做一些 声音的家伍的 以前的那个天下 我跟个人做点声音 就是这个人还是说 是叫我们的电子 或是我们去认为的电子 好,许贵了 可以 他们去许贵的话 那就是我们去许贵 那个电子 对 这个一条声音不是很方便 是我们有关系的作语 是我们有关系的 许贵的话 我们去许贵的话 是我们去许贵 然后这个 那个 这个 你这个 是 然后 然后 你能不能也可以的 做点一些许贵的话 这个叫我们去许贵的话 你许贵的话是我们去许贵的 然后他那面和他们想想 在他公圈过一些点 然后一起许贵 就想 然后 然后 通常我也是去许贵的许贵 就是你这个许贵的话 我说是说 我许贵的许贵跟朋友 就是不可能 的同样 可能会有关系的情绪 或者是没有关系 所以 如果 超看你的 革命 只是在看的这个病 你有病 你觉得病不难 但因为我会也担心 就是 你会在那边 抗许贵的 抗许贵的抗许贵 抗许贵或者是你对 抗许贵动作 你的许贵是你 所以我暴脱 但是我建议是我们 只剪小发布的 抗许 我们前面就只剪一个 有一张长 抗许贵 如果抗许贵是一口 有一张长不错 那是 如果很决 不错 等着剪划 后面的话 可以让我 或者是我们的剪达 就付剪 这样的话 我们要干嘛保证 放时间 一定能当成路 当成错的那天 花小的一点的成本 我们今天知道 你这双方的那个材质 可以吗 我今天是一个很没有材质 是一个很不错 现在就是 贵这个时候会错 贵是很容易的 就是上回家 抗许贵的些做的 是会在地上的电池 你的房会的样子 我就会许贵的材质 抗许贵的材质 我们去办门 我们去办门的材质 我们去办门的材质 我们去办门的材质 我们去办门的材质 我们去办门的材质 我们去办门的材质 我们去办门的材质 我们去办门的材质 我们去办门的材质 我们去办门的材质 我们去办门的材质 我们去办门的材质 我们去办门的材质 我们去办门的材质 我们去办门的材质 我们去办门的材质 我们去办门的材质 我们去办门的材质 我们去办门的材质 我们去办门的材质 我们去办门的材质 我们去办门的材质 他扮演下来部份手情 arena 他扮演下来中途根王 然后回头 不是 不是 你说情 Dialare是真的完全实在, 扮演下来去了解, 他这个茶总是不会听得到了, 但是我们像是在战因这个宝宕一点, 然后比如说国家这个地上的时间 ute 有什么算是这样的话 我挂到这一周 熟了会唱的 土豆口 你应该会跟着我提派人放强 他没有的人做的 怎么唱吗 你都得好 这样这个方便 土豆口 这个提派人 这样让我劝他支持 这样 这个方便 这个是正常的 那我会有我也说 这个地方就是进入错 那我会有我也 这是会有一些人 那只是他們這一層控的遇遲比較高 他們不會認為這支種航 但對於你來講 你可能對於你航控比較平安 對於你去撒派這裏 如果我以為你是英國領導或者是執行店 但是問你這兒舌 馬上跟著舌 那我這麼會有我肯定也行 你有沒有有時候去拜託嗎 我拜託他不會有後這兒也去舌 那肯定就沒辦法 那我現在有時候才會教你 有時候有什麼關係 還想你做移動的那種感覺 就說就是一旦這個 有活動的時候 就是如果你來做這種動的那種感覺 結婚就很有感動 你快點玩 這是你的這個古迪古迪的這個恐怖屬 這裏面哪個英國領導力 所以你會靠下了尾迪 古迪 幫我們取寬 但是你古迪迪去取寬 古迪又沒有力量去升級了 其實古迪那位跑這個幫查理 教導環境跟德拉拉頂主的影響 如果你虛弱大導虛寬你可想想 小導虛寬你不想想 就是這個叫你核心鼓勵 就應該正常來講的話 我們應該是靠我們的這個 要辣椅或者是靠我們的福基去去做的去 所以沒有太大問題 這個膝蓋很厲害 或者說從小來講的膝蓋的問題 只說彩 從這個膝蓋的問題 我們可以做的 小導虛寬你 這個膝蓋很厲害 這是小的 所以我認為你用這個 這個膝蓋是大的 大的膝蓋是大的 小導虛寬你 這 這 這 這 這 這 這 這 這 這 這 我稍微發電話是不是 這樣 這 這 這 這 這 這 這 這 這 這 這 這個 這 這 這 這 這麼大 所以我那边这个地方突出来了 对对对 所以我那样超过一点点 把这个关掉这个小 但是我喜欢你的点 但是这个点 那一天 加点了 你要点点了 还有多少 而且在一会儿 去带我把它拿出来 或者是小小的 我就觉得这些地方 到了 因为要不然 去带 不然都没有去 只伤到台的男子 这包还弄得,二位这床都会不浪手了 而且你包转的应该还是选择的包子呢 对,对,所以我发现这个包子 你能不浪吗 承难,你能说小包的一点 或者是你靠背一海的一点 背着后面,你包海的什么床件 这床就是你有的时候是比较发奇的 要哭了,但是我要抱他 然后人就不动我回家 他连救我,他也要我抱 你们这样,你做的吗 这张路前放到我看,就不需要站的包 你这样的抱起来,让你做得多 你就站的包 因为你站的包 对你再说话,他们的家里有个小型 让这把包放在圈子吗 这么多 你这么多,那小二人也有了 所以你不开价地打 对你胸罪,你不价地不价地不敢 就管他抱了小子 三月份一下,我已经开始蹭了 我已经都抱起来,那一项是小二 但是你长期的老婆 对你腰这一样的小子 所以我如果你是用床紧,我听了一项 你床紧是个安 那不安逐,你做的,也一样的 这儿我已经做理解了一宝,让他脱一脱 那你就长期间在床紧的包 我一直在老婆,你看不着我,对不起 那会儿就一样 谁呢 来,坐下来 这儿我已经过去,我们看见 那对你身边的困难情化 还有没有拿来的地方,我就觉得 这儿我已经在床紧了,我看不来 我今天在床紧的老婆的小子 也有很多人 所以我已经不可以看 看不着我 我们后面要去洗飞的吧 那我们要去洗飞的吧 那我们要去洗飞的吧 这边一个小孩的口试 以及真的跟着喜欢的甜甜甜甜甜甜 然后我们是伤害的扩把它就给你可以看一下 我们今天是有一个手机的服务的背景 接着拿手机的 然后我们或许的抗拭当年实际这个整体的关系 要付出规矩自身 然后还有我们的手机 然后我们一节扩到它是一个小时 对然后这部分那些是他们的手机 你可以看电影的时候 它有安全性 它被你安排的是帮助和我们的手机 因为你等你打火 如果说你打火 那种电影只有我们的手机可以给你分析一下 它的抗拭 但是不仅可以调查我们是因为我们可以还是意义的特点影 因为我们的体制要追一周的位置 就是这个其实是个体制的背景 它是那种要追的 因为我们要去手机制的是的 它各种点个爱点 但是不是一种我们的影像和我们的影像 那他要是一点特首图体 然后是一个小时的手机 就是传达 传达有时候我们印象和可能是为 我们会上一个简单的科学后 我们就那个去庆抗 我们再去拆查我们的手机 因为它很多是考慮的效果 它会带到你的指题 对 就不带它是只是对于你这速度的 整体的完了也需要把控 然后会有一些虽然的细节 以及我们是说是要点点 或者是要调话 对 那是我们对我们的数字 我们是一点科学 我们的数字是说了 10.5%的消败 还有很多科学 我们可以按照一个角色来 到我们也想看一下 短短的程度 然后在于这边后期的一个节话 对 那如果是刷点科学 我们中间传达手机的饿了 手机的饿的配置 我们 我们大概13.5%左右 然后包里的话 我们可以按开九节克左右 刷掉和港澳 在10这样的理解 但也会订与无说你可能 刷的但是结构左右 我们都会刷开加坡 如果这种好了话 你发现的照片也好 在家里面一起的视频 我稍微也比较好 那可能我们变加坡 可能会刷到空别的数字 对A3的话 应该比较大的数量的药控制器 对A3的数字 所以我们都会设计 所以我们都会设计 然后再问好 我们可以按照一下 按照一下两条红 我们可以按一下按按照我的手机 对 那是要么 其实我们也都做了很多 每天都会按照 都会订阅 会个距禅 客啥比较成理的手机 客品 我们是个距禅 今天的职务名的 车上提外订阅的主缩 我们去制定你的手机的电话 当手机的电话 我们上完之后 会订阅我们去制定的电话 对A4的计划 但是每每一次的车是听到 我们都会安排你的空服势 因为空服势会为了自己的空服势 你们会有我们的空服势 以及我们的徒徒徒徒徒徒徒 所以我们有一个意大量的控制 会有哪会有哪会有哪会 或是我会有一个 包括群方案 我们会有快感 就大家我的告诉你第一个节段 或是要么节段 第三个节段 我们都会有一个话感 但这几个节段 我们的节段 可能只能比较特征 它会是会给到你 因为我们在第一个节段 还有正常有可能通 我们的第一个节段 可以是一块的节段 正常的可能通过去 对的 你包括这个 最后你也是会在这个包包里 用吗 最后的还没有 但你这张 三次节段 可以啊 第一天才会照 或者是我们这样的量量 你可以开一下 对 我同时如果学校来到我可能 这个时间才会 是因为现在是到了 快要放下的时候 跟我们做场比例的 我需要的 就给你可能学校的手里 让大家一起比较好的 对不对 让大家可能会 就是让你多一年 把我的包包 我已经清楚 他真的知道 我算是自己这样 OK 但是可以开一下 跟我们唱歌的一会的 还有什么就有空了 所以我们目前都 就是杀给快捞 手机的甜蜜 被给一点点 都没有吐费到 然后因为我们现在 比较一下 三节段的时候 结果我们就结果 比较重复的话 比较一百年 那我们现在是 这个你可以开开 这个家庭照顾 这位家庭照顾 这位家庭照顾的 你是说我可以跟第一个 不用的 那如果说 哪是你这边 比较小的 你的意思是 他的话是 有一个 以外的话是我们曾经一天 对 然后了外的话是 然后在天下 就等于是多了一个分钟的 你 不用说 所以我会认识 对家庭相派甜蜜甜蜜的 因为我现在 很好 可是这篇家庭也是 一百年的百年 一百一万 所以 就等于回家 这个金融长会有一个 一千个分钟 这个分钟就是 不用 但是他就是 我不是 对 直接比较你是 那是吧 就不用去 我会跟着你 上的那位 我们就困定 会控制的不室辈 那一屏幕会还是 那是你开的 对 牛腿还是打头 来的 就因为我们 上了牛腿是两天五 那我们如果说 你今天去 你好像要开始 好活动 后排的要吃到 我还叫你 跳舞给你收拾 对 那如果是今天我们 才去你不了 那我们就变成 今天只先收拾 你过来跳舞的一个 鼓的鼓的肥 然后控制的 还是只能后排 都吃到 我们就按照你正常的 用去给你收拾 对 如果是要去我 你舅舅 今天不是要去你 直播吧 我们今天就变 对 你今天就变成 你还是要去你 对 因为你不可能比较多 每天是自己 对 如果说排的比较多 那就去我去你 你会打个比较多 你今天就会打个比较多 对 对 所以今天如果 就变成 最后就变成 我们每个都会 加达 我把它通过 因为我这个 就只能吃到 所以他比 所以我們就在這裡找到很久的 謝謝 謝謝 謝謝 謝謝 謝謝 謝謝 謝謝 謝謝 謝謝 謝謝 謝謝 謝謝 謝謝 謝謝 謝謝 謝謝 謝謝 謝謝 謝謝 謝謝 謝謝 謝謝 謝謝 謝謝 謝謝 謝謝 謝謝 謝謝 謝謝 謝謝 謝謝 謝謝 謝謝 謝謝 謝謝 謝謝 謝謝 謝謝 謝謝 謝謝 謝謝 謝謝 謝謝 謝謝 謝謝 謝謝 謝謝',2,NULL,NULL,'2026-03-09 16:27:52','2026-03-09 19:07:39',0),('r_92f0e8f1d0de4d4c','v_53649889ebdc4121','audio.mp3',NULL,NULL,NULL,NULL,NULL,3,NULL,'音频转写失败: The \"path\" argument must be of type string or an instance of Buffer or URL. Received null','2026-03-07 12:00:34','2026-03-07 12:00:38',0),('r_b87dd5a342644899','v_bb73c402325a4389','肖成茜 2026年1月16日 视频2.MP3',66055573,0,'audio/mpeg','1773045282331-a4j1aunx7.MP3','如果把你的天早晃最多晃,你会觉得又是天击的,就会变好 如果是我的天击的话,这样也还好,还要不做工 算好一点 太好了,那邊 桌上 沒有什麼看不起 這樣會讓你覺得變好 這樣,這樣會覺得說不清楚 因為我今天不是感覺 今天不是痛,是這裡我覺得鎖得很死了 這樣有點不舒服 但是我覺得很特別 對,這個區域是 你覺得胡和你們喊 我不知道,反正我覺得這個區域 就是要壓一塊使用 壓不舒服 好,我們先 這邊 這邊 這邊 好,這裡我們來看寶石丁路線 丁路線 好,我們來看看我們 我們來看寶石丁路線 然後丁路線 然後丁路線 丁路線 丁路線 這張圖 好,可以嗎 好 這邊 這邊 這邊 這邊 這邊 這邊 這邊 我明白了 可不可以 我明白了 要不可以 要不可以 要不可以 要不可以 要不可以 要不可以 要不可以 要不可以 要不可以 要不可以 要不可以 要不可以 好 你現在開始要改召集 要不可以 因為這做用點 你感受一下 又特別點點 合作特定 這個這邊 这儿有轻松一些吧 这是小薰一根左边笔 然后一根上台笔 如果刚才的不舒服100层 或者左边不舒服100层 所以它右边 才不知道 或者说还有不舒服 嗯 但是左边是有不舒服的 有 有什么 但右边会轻松一些 有 或者让你右左边转移车几点 把你转移掉 这边是你的 把它放在这 对 小薰 好 这边 好 这个位置上点我 点多 对 把小薰 放松一点点回去 然后自己 把这个位置上 底下来 上 上 把小薰 可以让我估计吗 好 因为我会 因为我会 因为我会 因为我会 好 来 给我 给我上来 给我上来 好 来 给我上去 给我上去 好 来 给我上来 好 这边是要上去 这边是要上来 现在你先右边上去 这边是要上来 给你右边上来 好 这边是要上去 这边是要上来 这边是要上来 好 这边是要上来 这样 在四角 往上到 滚 这个位置 枯萝 好 对 在這裡怎麼不住? 這裡就是酸藏藥 然後酸藏人不覺得很低 這位很健身 而且我有課會到 好 你覺得這個不合理嗎? 嗯 有一點 對,這裡有按下去,我會痛 站好 這裡痛 好,這樣 稍微一點,還是一點胸 稍微上你的胸 你現在你的感覺 好,稍微舒服一點 我可以說一點 就是你現在這個補充的肥脂 因為應該我腰點 因為不重要,直接給他做的前面 好 你現在用前面的肩膀 掌握這邊的部分 第一部分是你的 上手的肌肉 你上手的肌肉 你的 from your肌肉 你的肌肉 脆脆脆脆脆 脆脆脆脆脆的脆脆脆脆脆脆applause 好 好 現在第二,現在向你的胸從�dan給肚子 對不起,這樣膽就不行 而你一生是挺好的一日要挺的兄弟教 所以你的兄弟是在你身上 當你的兄弟兄弟是在你身上的時候 那你的頂部你往前 所以你的這個頂部提到的那一個地方 所以大家就這樣 他這樣一直在這個位置 他不在那裡,所有家裡就在那裡 如果像是這張 稍微回到正式的一個兄弟兄弟 使出的時候 讓他們之間的苦線 他們就在那裡去了 這個位置怎麼樣就在那裡 所以說把我剛才跟你在客人的 在玩家盯過的時候 正常是在玩家的外宣 應該是九十 內宣應該是七十 但是外宣 大概九十 在內宣大概之後 二、三十多 盯過很小 就說你的心家不一直在著 厚天地上的胸擴 也是不可能一個 有心理的照片 那麼也要看他跟你平常 你最心理的體態的關注啊 各方面有關 所以我們後面的話 其實反而還需要去恢復你 從四個身上的學術 對後面我們可能會 帶你去做一些教股盤 胸擴最有關的練習 這個是 最領導的 這個第二個位置的同胞 是在上面 第一個點的就是 你低壓股這個位置 你也跟你兄弟 有時間去玩 因為正常的胸擴上的屬度 就在這邊 就像是一個延地 我們間家股 就算是攤延久 攤著的延地上 他們之間應該是有這個 模樣的以後 它有一個支撐的 但是你現在目前的這個 胸擴是椅植的 按照跳的一個延地 那你今天要在上面 復活動度 車上的腳 這樣的話 今天上的機械 先講提機上行方機 他們會一直 扯一個緊張的腦袋 還要拉著你 還要拉著你 所以 它就給你 不過我剛給你夠確定了 其實是告訴你的 今天五交往上 去法律 交給你今天 不要把他按提 去訓練上行方機 這樣要拉著你 上的機械 你的監駕提機 是往後 所以我認為 你今天 常常應該是監駕提機 所以這樣的話 你的監駕股 有另外一股力 兩個 拿拉上去了 但是這個 也是製表 跟本來的本 其實在於你的 胸歷程度上 就是 我們需要改成 胸歷程度 讓你的盡量 可能騙了 實際上 它也不會有破壞 這原理就是這樣 所以早上 這兩個問題 都給你的胸歷了 有關 你要的提示 所以你交那位置 一直不舒服 其實也是一面你的 胸歸的一直出來 你走 前不去 那胸歷是挺著 就是你現在 在這兒 你走 你走 你走 所以我們先需要讓你 順利歸前面 回來 把你的股盤 前這樣 回來 這樣的話 你的身貨 那股盤 和腰歸 它才是你說 遂樂的動 它可能發揮你 那股肌肋 那些 原理是那種 原理 然後有利用的時候 容易習慣 你走 你現在也習慣這個觀念 是 這跟你的估計模式有關 因為你的身貨 它這樣 你的橫邏 它的估計能力 就會受出手 所以你就會選擇 估計 你會靠你的定量 低 你的肌 去幫你疼 這是一種 低效的 一些 擺行式的 呼吸模式 就是這 呼吸不良 你才會用這種 我是呼吸 因為我上一家課的時候 我也感覺 我是比較 正常分享的話 應該是似乎 就是女生 也要用估計 所以後面的話 我們來看過 我的弄交 其實這上子 似乎 估計 估計 估計 估計 估計 估計 估計 估計 估計 估計 估計 估計 估計 估計 估計 估計 估計 估計 估計 估計 估計 估計 估計 估計 估計 估計 估計 估計 估計 估計 估計 估計 估計 估計 估計 估計 估計 我许令人能帮你 因为这个就已经有点带我们在康复的阴界的地方 我只能说是看 就是我们康复可能组织这个 我觉得我们还是先几个先几个阴界 要为我 但你们这个领导 这个领导 就是我们这个领导 就是我们这个领导 就是我们这个领导 就是我们这个领导 就是我们这个领导 就是我们这个领导 就是我们这个领导 就是我们这个领导 我们这个领导 就是我们这个领导 你们先拍照 或我看一下 然后你们看一下对手 我这时候都受不了 但一会儿 如果都出女后 我们小把手 先来演员 然后我们会放点干子子 我是 還有點薄荷、點點即可的, 玉琐點什麼, 因為,因為, 非常好, 其實, 所以, 只有, 一點點比較好, 你真有危机 透了 你这是从户的时候 有机会很整体 就是我在车它这个位的时候 它会有些情绪 有机会八大多 或者它有些情绪 情绪被释放出来的感觉 因为这地方它有一个情绪 它可以处置一些小小的情绪 你这边很疼 不过我们有点疼 我们有点连来的房子 可以说你还好 然后下一个位置 继续处理解 所以一次 你之前弄好上面 你太讲了 所以还是你考完这个地方 可能在这里装机 然后下一个位置 就让你处置 就让你处置 然后下一个 边来 然后 然后 然后 然后下一个 然后下一个 你,你,你感覺的像是嗎?像嗎? 啊,我感覺就是裡面脫了,是有點麻 啊,就脫了之外呢? 脫了之外呢? 沒有,是不是,太大小了 沒關係,你們戴上,還是戴上 啊,就是因為你,那個,右邊的水咬啊 要的,我這是體育的問題 但是我現在看你的右邊的臉,體育看少了 啊,這個,在這個前,就這個好了 就这个题是稍微笑什么 因为你的意外第一他就鼓起来 所以会从刚才的再往来从来 但是你的嘴角下层这个问题 道法还可能是提低无力 这好办 可以做一些修炼 不修炼 对 你可以拿出来好 这个这个问题 你走归小修炼 真做最小修炼 这是个键 不是 是我放下纸转 然后去跟他做最好 不是 不是放在脑袋 是像下来 嘴角小 小 小 只 小 慢慢回 慢慢回 小 小 胖 脖子 小 胖 脖子 小 只有一点慢力 你觉得确实是多 实际 确实没 小确定 最近 然后 我觉得 多说一句 就是你看到有個委屈叫《Lifemium》 他為什麼微表情 直接能看出來一個人的情緒 是因為從零課學校來講 我們大腦大腦內地有一個叫邊緣技術 邊緣技術內地有相當和 相當的一種就會直接 支撐我們的面部的一些感情 但是你覺得要和肌肉 所以呢當情緒出現的時候 你就表情就會多自主出現 那麼反而就是表情出現的時候 也會有情緒的那樣 所以當你搞笑的時候 你的情緒也是好 所以你多做一個肌肉順便 接著你的情緒受關注 所以這個他們兩次互相一提 所以我覺得 他的經驗國那麼今天是先 如果需要發揮的話 可以按一下一點點點確 可以給他做一個經驗好的處理 但是主要不用找人的事 然後把他放開 我們的高級同時就OK了 高級同時就OK了 讓他去做一些 這個這個 安排可以 一點點好 然後讓他去做一些經驗 他一個情況就做一些經驗就OK了 然後你也可以稍微做一些 生的這樣我的甜點 我跟他做一些經驗 就是這對人安排是不是比較冷靜 然後或許他能去那邊會放進去 好 去會了 可以 那你去去會的話 那就 你去那邊進去 對 我這裡交通不是很方便 還是去那邊做一些舒服保護 去會了 然後其實我去那邊 去會 我再給你 你去 你去 你去後面去會 這樣回去 然後你用東西 然後你也可以隨便安排自己的 這個方向 因為你的方式 我們隨便安排 然後讓你安排他們安排 但是他不關鍵多一點點 然後一滴這裡 然後 然後 然後 我也不確定你問題 就是你這個情況 我只是說 我認為你的這個症狀就不分 的阻礙 可能會有關你的情緒 或是沒關 所以如果超看你的 各方面只是在看你的這個病 你的病其實並不難 但是我會 擔心就是你會來 跟抗拾的配合 以及你的抗拾情緒 或者是你對抗拾情緒動作 你的學習提前速度 所以我抱歉 但我建議是我們只 先少發給抗拾 我們先來個 有一張抗拾 12次 如果抗拾完結以後 哎 原來不錯 那是如果感覺過了 但就行了 後面的話 就可以讓我 或者我們的電腦 可以做護檢 這樣的話 我沒有辦法保證 當這間 一定能到我們程度 當我們怎麼說 每天 花少一點的成本 我們先來看 這樣的話 最雙方位的還要打一些 可以嗎 那我今天習慣 沒有看 啊 習慣也很不錯 現在就是 貴子的時候會痛 貴子 等著貴子 就是上個家客 我們會有一些做 貴的電腦電腦 你也在上個家 我就是不是 建議家才才能完成 那要不然 我們去外面 去家家 這床應該還好 那你去拿一袋 這床比較硬的 好 好的 有沒有 他們還折斯 其實這床 貴子是原來這樣是貴的 那這個印竹是不會痛的 但是我們上個異 家庭會保一點 然後比如我和這位 依據 總算是這樣的話 我看到這也是有所謂的 土豆豐 你以為要跟那個其他人唱一唱 他們有的人是唱的,有人不唱 有的人不唱 這個方面,土豆豐 這不是其他人 我問你這個,這是什麼 這我看來,這是正常的點點 那我會有我也的 這個地方就是金土豐 那我會有我也 那是會有一些人的那個 那只是他們對唐豐的育職比較高 他們不會認為這是一種唐 但對於你來講 你可能會對唐豐講明白 所以你再換這款這款 如果我以為你是冰鼓勵唐 或者是職房店 但是如果是這款 那還跟這款 那我這麼會 我肯定也有 你們我有時候去拜託嘛 我拜託他們不會有 到這兒也去討 那肯定就沒辦法 那我現在有時候談一下 有什麼關係 還想你做什麼東西 那我敢講 這個就是 習慣就要有活動的時候 就是如果你還做這種東西 還不敢講 其實跟你母親有關 跟你快有關 這是你的這個 補職機的一個服務服務 這經驗兩核心努力 所以你會靠想要的 補職機 幫助你去寬 但是你補職機去寬了 補職機又沒有力量去生氣了 直接補師傅 接待會兒考慮會幫查理 叫做蠻病毒的 跟拉丹病毒的成效 就是如果你 虛蠻大腦的虛蠻 你可想一想 小腦的虛蠻 你不想想 就是這個 就是你的核心努力 就應該這樣想 然後我們應該是靠 我們的這個 要大的一會兒 靠我們的服務機 去做的虛蠻 所以你沒有踩到問題 這個膝蓋問題 或者說 從早來講的膝蓋問題 有時候踩 從這個問題 膝蓋的問題 可能會有 什麼叫 雞翅 雞翅 -V酒 -雞鞍 -雞翅 -酒吧 酒吧而我們應該也 你有什麼 你怎麼把這雅鞭爆 electrons 這雅鞭爆 -應該知道 -一次 -中 -目前 -覺得 吃野 --吃 那是在那裡 12不穩定 我稍微差一點的話就不穩定了 不穩定了 不差一點就不穩定了 12的12 差12我就不穩定了 還稍微處理一下 我們他們是要把這個手機公里給 如果要處理的話 如果你的手機公里是要處理的話 他們是一定處理的手法 一定把手機公里給 去規復這個手二的這個 還要處理 這關也是不在這內心 原來充 嗯 還在充 你先看這個手機 你先看這個弄個會上 是 你裝那麼 你裝那麼 你裝那麼 有人在這裏 有人在這裏 有人在這裏 有人在這裏 有一定 有一定 好 好 你給 me好 好 好 好 就是這邊 剛剛好看 你看 好 好 進裝後頭暖的 好 好 困难,你能说少报一点? 或者是你靠卑鄙海的名字? 卑鄙海的名字? 卑鄙海的名字? 你报海的是什么场景? 报海的名字就是 有的时候,比如说他发脾气了 要哭了,那是我要报他 然后又说不让我回家 他研究我,他也有报 你能不能这样做的报? 这家女性放到我台来都不需要站着报 你跟他报起来让你做一步 做一步 你就这样报 因为你这样报 对你的社交困难家里有个小信 让你把他放在车上这么报 他说你这么报,对于12个女人 所以你不陪下来打 对于兄弟也挺不压力之外 就把他报起来的发言类似来 我已经开始痛苦了 我觉得都报起来那一项是12号 但是你谈识的老报 对你教训了一项是12号 如果你是用场景我听了一下 这个场景是个安逸的 但是我安逸逸逸逸逸逸逸 但是我安逸逸逸逸逸逸逸逸逸 就是我已经做了一道 然后带他退道 他就喜欢走 那你就等你练在场一点这个话 可能你的老老你看不笑就会被看 好,好 好,那后去你两个吧 好,好,好,那这些 我最近经过过去 我们看一家地位 今年突然的情况还没有哪一个听说的 或者在那里过去的康徒压体的压体 从来过去的人 当然是怎么样的 所以用什么用的时候可以看着 看着就可以看 我们后来因为要去学废的办法 然后刚刚上了 所以就会给你安排了合适的康徒师 以及将对你们的情况 那前期便宜你做一个课程 然后我们是12个课嘛 那这边你可以看一下 我们今天学为一个首次的礼物的朋友 结成老师的 然后我们后续的康徒师 分别试证这个课程 然后主观一阶子身 然后还有我们的手机 可以课的话是一个小时 对的我这么分别是他们的会试证 你可以看电影试证 因为它弄得还不是 它可以安排的是 话题和我们的手机 因为你们的面下和 如果说面下 或那中间只有我们的手机 可以给你做面下和的康徒 但是不前一套为主 因为我们可以还是一名的特别 用我们的计划要追以这种为主 就是这种其实是 对对对对 其实是这种 因为这种其实是 它会中间会矮一点 但是不是以我们的面下和为主 对 它是一点特的时候 从事让我设的事 不就是穿擦 穿擦的有时候 我们面下和可能是 为辅助的话 那可能我们会下一个 解放的课之后 我们就那个继续停泡 我们再去穿擦 我们的手机 因为它不光是靠谷也能接下过 它会拐到这个身体 对 就不单单是只是对于这种谷 整体的把它也需要把控 然后会一些训练的细节 以及我们是否需要 定接 或者是要调化 对 对 我们是一个特区 然后前面我们称老师 就说了 每天一天你五天 不需要买太多的特区 所以安静安静 所以说要买太多的特区 然后我们也再开一下 你换这个程度 然后再继续继续的一个 主要训练的话 对 那如果是12点 或是我们中间穿它手机的 合了法 手机的合的配件 使用的 補助的话 手机的配件 我们大概13点合左右 然后高一点的话 我们可以压开9点合左右 12点合刚好 对 是这样的问题的 但是也不一定 比如说你可能上个30点合 左右我们能够穿它一家 或者你如果你做好了 的话你怀疑怀疑的照片 然后就在家 自己的保持累率比较好 那可能 我们这家 我可能会穿到后面的特区 所以这传讲 一家比较大的 主要是我们的腰控自己 最怕最怕最怕最怕最怕 最怕最怕最怕最怕 所以我们更多是一特区 重点回去 然后最后 我们可以给你擦一下 那你现在太接受 因爲80年 然後我們一個聊程的時候 此情不必是可以給你監獵的 對 監獵好的 監獵一天 常常是監獵一天 所以應該是兩天五 對 我們可以給你監獵一下 然後按個一天五的時候 對 那是要算 之前的節奏作曲 每一段時間都一樣都一樣 對 因為會有一個 劇名科下表稱的首劇 是根據您今天的評估 您的水焦題外 您的主訴 我們去指令您的首劇和計畫 那麼 首劇和計畫 我們上完了之後 會跟著您上完第一 也喝之後 您的打會 您的懷舊 我們去指令教育的計畫 我們覺得 但是你每次的科學計畫 我們都會搭載您的康復群內 因為候選就會有一個 自己的康復群 你們會有我們的康復師 以及我們的同時都會在裡面 這有一個一大段 同時都會有搭 或許我們會有圓芭芭圓芭芭圓芭芭圓 我們會有快甲 就大概我們的高次 你第一個節奏 或者就要不然節奏 第三個節奏 我們都會有一個快甲 但是劇體比較細的 跟著計畫 可能只能比劇科長 它不是會給到你 對 因為我們在第一個節奏 還有這段 有疼痛 我們第一個節奏 可以是以懷的 你的這段和疼痛為主 對 好的 你包括這段 最用的也是會在您的包合理由嗎 對用的還沒有的 但你這段 單子可以的 可以啊 你聽聽聽聽 或者說 我們這個降表 你可以直接開一下 對 所以非常清楚 我後續 如果說要來 我可能 這個時間不太好 是 因為現在是到了我 快要放下的時候 我工作場地是不提黑的 我需要在 就是你可能收集的時候 你們轉來就比較好的 就在工作了 轉來這樣可能會 就是在這段會多一點 就快樂的話 我是清楚它 就知道 小伙伴是怎麼樣 OK 可以開一下 最有上面還有一個 有一個問題 還有主播就有空了 我們目前的話 就是 雜點 快繞首次的節目 可以見面 就沒有準備到 然後因為 我們現在 給你算了一下 三節的時候 我們就覺得 到底會是看 總統的話 跟我們是一年八年嘛 那我們現在是 這邊你可以看 還有一個單子照顧 這個單子照顧的 其實是我們 可以跟基礎公用的 但如果說 雖然是你這邊 沒有需要你 可以自己問你需要 它的話是 有一個一萬的話 是會增多一千 對 然後兩萬的話 是增多三千 就等於是 多了一個增存率 怎麼可能 怎麼可能 比如說 所以我們會 增存對待 有一千塊錢 對 增存率 因為我們現在 然後各式 可以看起來 也是一年八年 那買一年 買一萬 就等於可以在 這位基礎長會 會有一千的增存率 這增存率是 怎麼用 那就是 增存率 對 增存比 在你身上 是嗎 就等於是 我們會跟著你 上了每一位 抗議室的課 我們就 抗議室的課 是每一批 五分還是 不離開的 對 五分還是 對 因為我們 上了一批 五分還是 兩天五 我們如果說 今天你決定好 你需要開始康復 然後工程 然後我們 就要一天五 去給你收取 對 但 如果 今天我們 上了一天 我們會 從這個 一個數字 的頂部的 費用 然後後續的話 你正常 和百分之一 就按照你 正常 對你 去給你收取 那我 稱呼 我 我們 今天 要不要到 可能 你今天 累了 你出來給 你可能 愛了 因為你 可能 比較多 我們等一下 今天如果等出到最热情的工作之后 我们每个都关一下 然后把他的床的建议 这些都准备出来 然后可以再给你 今天我说一下你找个很生的 谢谢 谢谢 谢谢 谢谢 你提醒身体体 老公不好 你也做笑笑 刚才你进来 我看在你有点严肃 我说不太乱严肃 他会是 我说他不少的一半 所以我刚才就要再做一下 然后一口笑点 法定人數不足 法定人數不足 法定人數不足 法定人數不足 法定人數不足 法定人數不足 法定人數不足 法定人數不足 法定人數不足 法定人數不足 法定人數不足 法定人數不足 法定人數不足 法定人數不足 法定人數不足 法定人數不足',2,NULL,NULL,'2026-03-09 16:34:42','2026-03-09 23:12:59',0),('r_e2c78a1419c64b68','v_1502f5b66d3940c0','audio.mp3',NULL,NULL,NULL,NULL,NULL,3,NULL,'音频转写失败: The \"path\" argument must be of type string or an instance of Buffer or URL. Received null','2026-03-07 12:08:42','2026-03-07 12:08:46',0),('r_f4ab974e55c646c6','v_a1b1cb3177ae4238','肖成茜 2026年1月16日 视频2.MP3',66055573,0,'audio/mpeg','1773044534120-47ubeaukjp2.MP3',NULL,3,NULL,'音频转写失败: ENOENT: no such file or directory, open \'1773044534120-47ubeaukjp2.MP3\'','2026-03-09 16:22:14','2026-03-09 16:22:18',0);
/*!40000 ALTER TABLE `recordings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `template_fields`
--

DROP TABLE IF EXISTS `template_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `template_fields` (
  `id` varchar(32) NOT NULL,
  `template_id` varchar(32) NOT NULL COMMENT 'æ¨¡æ¿ID',
  `name` varchar(50) NOT NULL COMMENT 'å­—æ®µåç§°ï¼ˆæ˜¾ç¤ºï¼‰',
  `field_key` varchar(50) NOT NULL COMMENT 'å­—æ®µé”®ï¼ˆè‹±æ–‡ï¼‰',
  `type` varchar(20) DEFAULT 'textarea' COMMENT 'ç±»åž‹ï¼štext/textarea/select',
  `required` tinyint DEFAULT '0' COMMENT 'æ˜¯å¦å¿…å¡«',
  `sort_order` int DEFAULT '0' COMMENT 'æŽ’åº',
  `placeholder` varchar(255) DEFAULT NULL COMMENT 'å ä½æç¤º',
  `options` json DEFAULT NULL COMMENT 'é€‰é¡¹ï¼ˆselectç±»åž‹ï¼‰',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_template_id` (`template_id`),
  KEY `idx_sort_order` (`sort_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='æ¨¡æ¿å­—æ®µè¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `template_fields`
--

LOCK TABLES `template_fields` WRITE;
/*!40000 ALTER TABLE `template_fields` DISABLE KEYS */;
INSERT INTO `template_fields` VALUES ('f001','tpl001','主诉','chief_complaint','textarea',1,1,'患者就诊的主要症状和持续时间',NULL,'2026-03-05 20:21:19'),('f002','tpl001','现病史','present_illness','textarea',1,2,'详细描述疾病的发生、发展、诊疗经过',NULL,'2026-03-05 20:21:19'),('f003','tpl001','既往史','past_history','textarea',0,3,'既往疾病、手术、外伤史等',NULL,'2026-03-05 20:21:19'),('f004','tpl001','个人史','personal_history','textarea',0,4,'吸烟、饮酒、职业等',NULL,'2026-03-05 20:21:19'),('f005','tpl001','家族史','family_history','textarea',0,5,'家族遗传病史等',NULL,'2026-03-05 20:21:19'),('f006','tpl001','体格检查','physical_exam','textarea',1,6,'生命体征、各系统检查结果',NULL,'2026-03-05 20:21:19'),('f007','tpl001','辅助检查','auxiliary_exam','textarea',0,7,'实验室检查、影像学检查结果',NULL,'2026-03-05 20:21:19'),('f008','tpl001','诊断','diagnosis','textarea',1,8,'初步诊断或最终诊断',NULL,'2026-03-05 20:21:19'),('f009','tpl001','处理意见','treatment','textarea',1,9,'治疗方案、用药、注意事项等',NULL,'2026-03-05 20:21:19'),('fld_fe5a12e9ef','tpl001','左髋角度','left','textarea',0,0,'',NULL,'2026-03-07 13:26:26');
/*!40000 ALTER TABLE `template_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `templates`
--

DROP TABLE IF EXISTS `templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `templates` (
  `id` varchar(32) NOT NULL,
  `name` varchar(50) NOT NULL COMMENT 'æ¨¡æ¿åç§°',
  `description` varchar(255) DEFAULT NULL COMMENT 'æè¿°',
  `is_default` tinyint DEFAULT '0' COMMENT 'æ˜¯å¦é»˜è®¤æ¨¡æ¿',
  `prompt_config` json DEFAULT NULL COMMENT 'AIç”ŸæˆPrompté…ç½®',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='ç—…åŽ†æ¨¡æ¿è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `templates`
--

LOCK TABLES `templates` WRITE;
/*!40000 ALTER TABLE `templates` DISABLE KEYS */;
INSERT INTO `templates` VALUES ('tpl001','标准病历模板','通用门诊病历模板',1,NULL,'2026-03-05 20:21:19','2026-03-05 20:21:19'),('tpl002','内科模板','内科专科病历模板',0,NULL,'2026-03-05 20:21:19','2026-03-05 20:21:19'),('tpl003','外科模板','外科专科病历模板',0,NULL,'2026-03-05 20:21:19','2026-03-05 20:21:19');
/*!40000 ALTER TABLE `templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` varchar(32) NOT NULL COMMENT 'ç”¨æˆ·ID',
  `name` varchar(50) NOT NULL COMMENT 'å§“å',
  `phone` varchar(20) NOT NULL COMMENT 'æ‰‹æœºå·',
  `password_hash` varchar(255) NOT NULL COMMENT 'å¯†ç å“ˆå¸Œ',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT 'åˆ›å»ºæ—¶é—´',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'æ›´æ–°æ—¶é—´',
  `last_login_at` datetime DEFAULT NULL COMMENT 'æœ€åŽç™»å½•æ—¶é—´',
  `is_admin` tinyint DEFAULT '0',
  `failed_login_count` int DEFAULT '0' COMMENT '连续登录失败次数',
  `locked_until` datetime DEFAULT NULL COMMENT '账户锁定截止时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_phone` (`phone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='ç”¨æˆ·è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('admin001','ç®¡ç†å‘˜','13800138000','$2a$10$LraHKCO7tN/X7LFsvrGtcODVD4CJKUSrZ4SMcLACWxEgh.uJ0bB.q','2026-03-05 06:56:20','2026-03-09 23:07:59','2026-03-09 23:07:59',1,0,NULL),('u_00c81b58473d40da','李医生','13900139002','$2a$10$.ZDxrGtXTlsjQvsmCAz3ZOMUCN.Wxv12zfw0BcH8/6t2QSfnIkeVG','2026-03-05 06:58:44','2026-03-05 06:58:44',NULL,0,0,NULL),('u_39923779a8724c1d','王医生','13700137000','$2a$10$M59ZXI5Q6GiNl2J4f5G6NeQdURRkgFLGcjMacEgy3qbMwfNv1nI2a','2026-03-05 07:01:29','2026-03-05 07:01:29',NULL,0,0,NULL),('u_61f732d5e9b14454','李涛','18610396605','$2a$10$oMnalMkTZZAWpQ5rZQIvHed1yoXsF7thf/rgddKqjeT3jidY7RmEK','2026-03-05 11:44:04','2026-03-10 11:00:52','2026-03-10 11:00:52',0,0,NULL),('u_f1cb674a92be4bca','张医生','13900139001','$2a$10$K5za1xCiEImhmGrcjAVkIud7Degwxl3pyz85pn76JaZr.3WL7NEj2','2026-03-05 06:56:47','2026-03-05 06:56:47',NULL,0,0,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `visit_records`
--

DROP TABLE IF EXISTS `visit_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `visit_records` (
  `id` varchar(32) NOT NULL COMMENT 'å°±è¯ŠID',
  `patient_id` varchar(32) NOT NULL COMMENT 'æ‚£è€…ID',
  `user_id` varchar(32) NOT NULL COMMENT 'åˆ›å»ºç”¨æˆ·ID',
  `visit_no` varchar(20) NOT NULL COMMENT 'å°±è¯Šç¼–å·',
  `visit_date` date NOT NULL COMMENT 'å°±è¯Šæ—¥æœŸ',
  `status` tinyint DEFAULT '0' COMMENT 'çŠ¶æ€ï¼š0è‰ç¨¿ 1ç¼–è¾‘ä¸­ 2å·²å®Œæˆ',
  `template_id` varchar(32) DEFAULT NULL COMMENT 'ä½¿ç”¨æ¨¡æ¿ID',
  `content` json DEFAULT NULL COMMENT 'ç—…åŽ†å†…å®¹ï¼ˆJSONæ ¼å¼ï¼‰',
  `version` int DEFAULT '1' COMMENT 'ç‰ˆæœ¬å·',
  `lock_token` varchar(64) DEFAULT NULL COMMENT 'ç¼–è¾‘é”Token',
  `lock_expires_at` datetime DEFAULT NULL COMMENT 'é”è¿‡æœŸæ—¶é—´',
  `deleted_at` datetime DEFAULT NULL COMMENT 'åˆ é™¤æ—¶é—´',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_patient_id` (`patient_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_visit_no` (`visit_no`),
  KEY `idx_visit_date` (`visit_date`),
  KEY `idx_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='å°±è¯Šè®°å½•è¡¨';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `visit_records`
--

LOCK TABLES `visit_records` WRITE;
/*!40000 ALTER TABLE `visit_records` DISABLE KEYS */;
INSERT INTO `visit_records` VALUES ('v_1502f5b66d3940c0','p_927161b3972d4435','u_61f732d5e9b14454','20260305-9561','2026-03-05',0,NULL,NULL,1,'lock_d19529e56dfd477e84f89f9dec221807','2026-03-09 08:39:30',NULL,'2026-03-05 19:45:37','2026-03-09 16:34:30'),('v_41ea1ad037854800','p_927161b3972d4435','u_61f732d5e9b14454','20260305-4640','2026-03-05',0,NULL,NULL,1,'lock_96afe8c5a81744a0ad558723eab0dcca','2026-03-05 11:59:43',NULL,'2026-03-05 19:52:10','2026-03-05 19:54:43'),('v_53649889ebdc4121','p_927161b3972d4435','u_61f732d5e9b14454','20260306-3799','2026-03-06',2,'tpl001','{\"fields\": [{\"content\": \"\", \"field_key\": \"chief_complaint\"}, {\"content\": \"\", \"field_key\": \"present_illness\"}, {\"content\": \"\", \"field_key\": \"past_history\"}, {\"content\": \"\", \"field_key\": \"personal_history\"}, {\"content\": \"\", \"field_key\": \"family_history\"}, {\"content\": \"\", \"field_key\": \"physical_exam\"}, {\"content\": \"\", \"field_key\": \"auxiliary_exam\"}, {\"content\": \"\", \"field_key\": \"diagnosis\"}, {\"content\": \"\", \"field_key\": \"treatment\"}]}',2,'lock_aea55d74f73749a1a5b9d1e03574d2c3','2026-03-09 08:35:30',NULL,'2026-03-06 18:42:57','2026-03-09 16:30:29'),('v_a1b1cb3177ae4238','p_927161b3972d4435','u_61f732d5e9b14454','20260307-4304','2026-03-07',2,'tpl001','{\"fields\": [{\"content\": \"\", \"field_key\": \"left\"}, {\"content\": \"\", \"field_key\": \"chief_complaint\"}, {\"content\": \"\", \"field_key\": \"present_illness\"}, {\"content\": \"\", \"field_key\": \"past_history\"}, {\"content\": \"\", \"field_key\": \"personal_history\"}, {\"content\": \"\", \"field_key\": \"family_history\"}, {\"content\": \"\", \"field_key\": \"physical_exam\"}, {\"content\": \"\", \"field_key\": \"auxiliary_exam\"}, {\"content\": \"\", \"field_key\": \"diagnosis\"}, {\"content\": \"\", \"field_key\": \"treatment\"}]}',2,'lock_c3ad9b451cdd4942af8308d9bc891566','2026-03-09 08:35:27',NULL,'2026-03-07 17:13:38','2026-03-09 16:30:27'),('v_abd19dbbfc224a91','p_227d2975889640ba','admin001','20260305-3668','2026-03-05',0,NULL,NULL,1,NULL,NULL,NULL,'2026-03-05 19:47:47','2026-03-05 19:47:47'),('v_bb73c402325a4389','p_7b3650ca4eb5436b','u_61f732d5e9b14454','20260309-2314','2026-03-09',2,'tpl001','{\"fields\": [{\"content\": \"\", \"field_key\": \"left\"}, {\"content\": \"\", \"field_key\": \"chief_complaint\"}, {\"content\": \"\", \"field_key\": \"present_illness\"}, {\"content\": \"\", \"field_key\": \"past_history\"}, {\"content\": \"\", \"field_key\": \"personal_history\"}, {\"content\": \"\", \"field_key\": \"family_history\"}, {\"content\": \"\", \"field_key\": \"physical_exam\"}, {\"content\": \"\", \"field_key\": \"auxiliary_exam\"}, {\"content\": \"\", \"field_key\": \"diagnosis\"}, {\"content\": \"\", \"field_key\": \"treatment\"}]}',2,'lock_59b3782067774f41a9f3f3ea6d1c662a','2026-03-10 03:05:58',NULL,'2026-03-09 16:34:38','2026-03-10 11:00:57'),('v_d275147bd62e42ca','p_927161b3972d4435','u_61f732d5e9b14454','20260307-9206','2026-03-07',2,'tpl001','{\"fields\": [{\"content\": \"\", \"field_key\": \"left\"}, {\"content\": \"\", \"field_key\": \"chief_complaint\"}, {\"content\": \"\", \"field_key\": \"present_illness\"}, {\"content\": \"\", \"field_key\": \"past_history\"}, {\"content\": \"\", \"field_key\": \"personal_history\"}, {\"content\": \"\", \"field_key\": \"family_history\"}, {\"content\": \"\", \"field_key\": \"physical_exam\"}, {\"content\": \"\", \"field_key\": \"auxiliary_exam\"}, {\"content\": \"\", \"field_key\": \"diagnosis\"}, {\"content\": \"\", \"field_key\": \"treatment\"}]}',2,'lock_f62c228904b0423c93e202b5981d6de8','2026-03-09 08:35:32',NULL,'2026-03-07 16:17:37','2026-03-09 16:30:32');
/*!40000 ALTER TABLE `visit_records` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-10 11:04:27
